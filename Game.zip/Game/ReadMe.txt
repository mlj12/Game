http://freegameassets.blogspot.com/2013/09/asteroids-and-planets-if-you-needed-to.html
http://opengameart.org/content/zombie-animations
http://opengameart.org/content/bird-animated