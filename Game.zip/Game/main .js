var frame = 0;
var lastUpdateTime = 0;
var acDelta = 0;
var msPerFrame = 100;
var count = 5;
var enemy = {};
var enemyKilled = 0;
var bgReady = false;
var targetReady = false;
var enemyReady = false;
var keysDown = {};
var finish = false;
var w = window;
var canvas ,ctx,canv;
var bgImage;
var targetImage , target;
var enemyImage;

var hop;
var shot;


requestAnimationFrame = w.requestAnimationFrame || w.webkitRequestAnimationFrame ||
 w.msRequestAnimationFrame || w.mozRequestAnimationFrame;
 
// $(function(){
	// $("nav").hide();
	 
 //});

	function startGame(mycanvas){
	
	canv = mycanvas;
	game_init();
	
	
	}
	
	function game_init() { 
	
	canvas = document.getElementById("canvas");
	ctx = canvas.getContext("2d");
	canvas.width = 800;
	canvas.height = 580;
	document.body.appendChild(canvas);
	
	
	// Load the background image
	
	bgImage = new Image();
	bgImage.onload = function () {
	// background image
	bgReady = true;
	};
	bgImage.src = "./img/forestbg.png";
	// load target image

	targetImage = new Image();
	targetImage.onload = function () {

  targetReady = true;
	};
	targetImage.src = "./img/target.png";
	// Load the enemy image

	enemyImage = new Image();
	enemyImage.onload = function () {
  // show the enemy image
  
  
	enemyReady = true;
	setInterval(update,1000/60);
	 
	};
	
	enemyImage.src = "img/frog.png";
	

// Create the game objects
	 target = {
	speed: 256 
	};
	
	hop = new sound ("./sound/jump.ogg");
	shot = new sound ("./sound/shot.ogg");
	addEventListener("keydown", function (key) {
	keysDown[key.keyCode] = true;
	}, false);
	addEventListener("keyup", function (key) {
	delete keysDown[key.keyCode];
	}, false);
	setInterval(counter, 1000);
	
	_reset();
	loop();
	}
// Reset player and place enemy in another place
	function _reset() {
  
	target.x = canvas.width / 2;
	target.y = canvas.height / 2;
	// Place the enemy somewhere on the canvas randomly
	enemy.x = 32 + (Math.random() * (canvas.width - 64));
	enemy.y = 32 + (Math.random() * (canvas.height - 64));
	}	

  // input from keyboard 
   function userInput (modifier) {
		if ( 87 in keysDown) { // W key to go Up
		target.y -= target.speed * modifier;
		}
		if (83 in keysDown) { //  S key to go down
		target.y += target.speed * modifier;
		}
		if (65 in keysDown) { // A key to go left
		target.x -= target.speed * modifier;
		}
		if (68 in keysDown) { //  D key to go right
		target.x += target.speed * modifier;
		}
		if(32 in keysDown) 
		if(
		target.x < enemy.x + 50
		&& target.x + 50 > enemy.x
		&& target.y < enemy.y + 50
		&& target.y + 50 > enemy.y
		
		
		)
		{
			shot.play();
			++enemyKilled; 
			count +=5;
			
			_reset();
		}
		
	
   }
   
// Draw everything on the canvas
	function  render() {
		if (bgReady) {
		ctx.drawImage(bgImage, 0, 0);
		}
		
		if (enemyReady) {
		ctx.drawImage(enemyImage, frame*64, 0,enemyImage.width/4,enemyImage.height/2,enemy.x, 
		enemy.y, enemyImage.width/4, enemyImage.height/2);
			//hop.play();
		
			
		}
		if (targetReady) {
		ctx.drawImage(targetImage, target.x, target.y);
		
		}
		
		
  // Display score and time 
	ctx.fillStyle = "rgb(250, 250, 250)";
	ctx.font = "24px Helvetica";
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.fillText("Enemies killed : " + enemyKilled, 20, 20);
	ctx.fillText("Time: " + count, 20, 50);
  // Display game over message when timer finish
		if(finish==true){
		ctx.fillText("GAME OVER", 300, 200);
		
	}
  ctx.restore();
}

// countdown of game
	function counter(){
	count=count-1;
    if (count <= 0)
    {
      // stop the timer
       clearInterval(counter);
      // game finish 
       finish = true;
       count=0;
       
       enemyReady=false;
       targetReady=false;
	   
	   
    }
	
	   
}


	//  main game loop
	function loop() {
	 requestAnimationFrame(loop);
	userInput(0.02);	
	render();
	
 
	}
	
	function update(){
		
	requestAnimationFrame(update);
    
        var delta = Date.now() - lastUpdateTime;
        if (acDelta > msPerFrame)
        {
            acDelta = 0;
            render();
            frame++;
            if (frame >= 4) frame = 0;
        } else
        {
            acDelta += delta;
        }
    
        lastUpdateTime = Date.now();	
		
		
	}
	//w3school sound code
	function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }    
}



function clearArea() {
	 
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
}
function restart(){
	
	
ctx.restore(0, 0, this.canvas.width, this.canvas.height);   
}